require('dotenv').config();
const express = require('express');
const axios = require('axios');
const fs = require('fs-extra');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.PORT || 3000;


// Prevents abuse by limiting IP to 50 requests per 15 minutes
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, 
    max: 50, 
    standardHeaders: true,
    legacyHeaders: false,
    message: { status: 'error', message: 'Too many requests, please try again later.' }
});

app.use(limiter);
app.use(express.json());


const shopifyAuthMiddleware = (req, res, next) => {
    console.log(`[LOG] ${new Date().toISOString()} | ${req.method} ${req.url}`);

    const { SHOPIFY_STORE_DOMAIN, SHOPIFY_ADMIN_API_TOKEN } = process.env;

    // 1. Verify Credentials
    if (!SHOPIFY_STORE_DOMAIN || !SHOPIFY_ADMIN_API_TOKEN) {
        console.error('[ERROR] Missing Shopify credentials in environment variables.');
        return res.status(500).json({ error: 'Server misconfiguration: Missing credentials.' });
    }

    // 2. Prepare Config for reuse
    // Using GraphQL Admin API 2024-01 version
    req.shopifyConfig = {
        url: `https://${SHOPIFY_STORE_DOMAIN}/admin/api/2024-01/graphql.json`,
        headers: {
            'Content-Type': 'application/json',
            'X-Shopify-Access-Token': SHOPIFY_ADMIN_API_TOKEN
        }
    };

    next();
};

// Route to Sync Products from Shopify
app.get('/sync-products', shopifyAuthMiddleware, async (req, res) => {
    try {
        console.log('[INFO] Attempting to sync products from Shopify...');

       
        // Fetches first 10 products with specific fields
        const query = `
        {
            products(first: 10) {
                edges {
                    node {
                        id
                        title
                        handle
                        status
                        featuredImage {
                            url
                        }
                        priceRangeV2 {
                            minVariantPrice {
                                amount
                                currencyCode
                            }
                        }
                    }
                }
            }
        }`;

        // Perform the API Call
        const response = await axios.post(
            req.shopifyConfig.url,
            { query },
            { headers: req.shopifyConfig.headers }
        );

        // Check for GraphQL specific errors
        if (response.data.errors) {
            throw new Error(JSON.stringify(response.data.errors));
        }

        // Format the data clean
        const products = response.data.data.products.edges.map(edge => edge.node);

        // Store data locally
        const filePath = './synced_products.json';
        await fs.writeJson(filePath, products, { spaces: 2 });
        console.log(`[SUCCESS] ${products.length} products saved to ${filePath}`);

        // Return success response
        res.status(200).json({
            success: true,
            message: 'Products synced successfully',
            count: products.length,
            data: products
        });

    } catch (error) {
        console.error('[ERROR] Sync failed:', error.message);
        
        // Handle errors gracefully
        res.status(500).json({
            success: false,
            error: 'Failed to sync products',
            details: error.response ? error.response.data : error.message
        });
    }
});

// Start the Server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});